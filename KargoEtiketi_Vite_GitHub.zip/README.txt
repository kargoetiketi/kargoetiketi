Cloudflare Pages build settings:
Framework preset: Vite
Build command: npm run build
Build output directory: dist

Barkodlar Code128 formatında oxunaqlı və daha seyrək yaradılıb.
Print: paper size 100mm x 100mm, margins none, scale 100%.
